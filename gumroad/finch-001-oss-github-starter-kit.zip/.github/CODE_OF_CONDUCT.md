# Code of Conduct
We want this project to be a respectful place for everyone.
**Expected:** be kind, assume good faith, give and accept constructive feedback, focus on the work.
**Not acceptable:** harassment, personal attacks, discriminatory language, publishing others' private information, sustained disruption.
**Enforcement:** maintainers may edit or remove comments, and temporarily or permanently ban people who break these rules. Report problems to <conduct@example.com>; reports are handled in confidence.
(Original short text, not the Contributor Covenant. Replace the contact address.)
