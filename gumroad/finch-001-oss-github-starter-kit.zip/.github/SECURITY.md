# Security Policy
## Supported versions
| Version | Supported |
|---|---|
| latest minor | yes |
| older | no |
## Reporting
Use GitHub's **Report a vulnerability** button (Security tab > Advisories; enable "Private vulnerability reporting" in Settings > Code security). Alternatively email <security@example.com>.
Include: affected version, impact, reproduction steps. Please do not disclose publicly until a fix is released.
## Process (edit these targets to what you can keep)
Acknowledge in <3> working days; assessment in <14> days; coordinated disclosure with a GHSA/CVE where relevant; credit to the reporter unless they prefer anonymity.
