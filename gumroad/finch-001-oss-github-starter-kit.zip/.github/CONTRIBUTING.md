# Contributing
1. Search issues first; for non-trivial changes open an issue before coding.
2. Fork, branch as `fix/...`, `feat/...` or `docs/...`.
3. Run tests: `<test command>` and linter: `<lint command>`.
4. Commits: `type: imperative summary` (feat, fix, docs, test, chore), max 72 chars.
5. Open a PR using the template. Keep it focused; small PRs merge faster.
Maintainers aim to review within <N> days. Participation is governed by [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md).
