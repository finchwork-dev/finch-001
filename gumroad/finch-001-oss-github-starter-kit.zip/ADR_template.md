# ADR-0001: Use PostgreSQL for primary storage
Status: accepted | Date: YYYY-MM-DD
## Context
(Example: we need transactions and relational queries; team knows SQL; expected size < 500 GB.)
## Decision
Use PostgreSQL 16 managed by <provider>.
## Consequences
+ Mature tooling, strong consistency. - Horizontal scaling needs extra work.
## Alternatives considered
SQLite (no multi-writer), MongoDB (weaker joins).
