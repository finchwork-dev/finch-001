# mytool
> Convert X to Y from the command line.
## Install
```bash
npm install -g mytool   # or: pipx install mytool / cargo install mytool
```
## Usage
```bash
mytool input.txt -o output.json
```
| Flag | Default | Description |
|---|---|---|
| `-o, --out` | stdout | Output file |
| `-v, --verbose` | off | Debug logging |
Exit codes: 0 ok, 1 invalid input, 2 I/O error.
## Limitations
- Files over <N> MB are not streamed.
## License
<LICENSE NAME>
