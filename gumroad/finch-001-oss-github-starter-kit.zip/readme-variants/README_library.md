# mylib
> A small library for X in <language>.
## Install
```bash
pip install mylib
```
## Example
```python
from mylib import parse
print(parse("2026-01-01"))   # -> datetime(2026, 1, 1)
```
## API
`parse(text: str, *, strict: bool = False) -> datetime` — raises `ValueError` if `strict` and input is ambiguous.
## Compatibility
Python 3.9+; no runtime dependencies.
## Versioning
SemVer. See CHANGELOG.md.
## License
<LICENSE NAME>
