# my-api
> REST API for X. Base URL: `https://api.example.com/v1`
## Authentication
`Authorization: Bearer <token>`
## Example
```bash
curl -H "Authorization: Bearer $TOKEN" https://api.example.com/v1/items?limit=10
```
```json
{"items":[{"id":"1","name":"demo"}],"next":null}
```
## Errors
| Status | Meaning |
|---|---|
| 401 | Missing/invalid token |
| 429 | Rate limited (see `Retry-After`) |
## Self-hosting
`docker compose up` — env vars in `.env.example`.
## License
<LICENSE NAME>
